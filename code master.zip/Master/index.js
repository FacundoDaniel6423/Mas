// index.js
const fs = require('fs');
const csv = require('csv-parser');
const createCsvWriter = require('csv-writer').createObjectCsvWriter;

const adFile = './Archivos/AD.csv';
const hyFile = './Archivos/hy.csv';
const outFile = './resultado.csv';

// Normalizar textos
function normalize(s) {
  return (s || '').toString().trim().toLowerCase().normalize('NFC');
}

// Leer CSV con separador ,
function readCSV(filePath) {
  return new Promise((resolve, reject) => {
    if (!fs.existsSync(filePath)) {
      return reject(new Error(`No existe el archivo: ${filePath}`));
    }
    const rows = [];
    fs.createReadStream(filePath)
      .pipe(csv({ separator: ',', mapHeaders: ({ index }) => `col${index}` }))
      .on('data', (row) => rows.push(row))
      .on('end', () => resolve(rows))
      .on('error', reject);
  });
}

(async () => {
  try {
    console.log('📂 Leyendo archivos...');
    const adRows = await readCSV(adFile);
    const hyRows = await readCSV(hyFile);

    console.log(`➡️ Filas en AD.csv: ${adRows.length}`);
    console.log(`➡️ Filas en hy.csv: ${hyRows.length}`);

    // Crear sets de nombres normalizados
    const adSet = new Set(adRows.map(r => normalize(r['col0'])));
    const hySet = new Set(hyRows.map(r => normalize(r['col0'])));

    // Unir todos los nombres únicos
    const allNames = new Set([...adSet, ...hySet]);

    // Construir resultado
    const resultado = [...allNames].map(name => {
      const foundInAD = adSet.has(name);
      const foundInHY = hySet.has(name);

      let estado = 'No encontrado';
      if (foundInAD && !foundInHY) estado = 'Deshabilitado';
      else if (foundInHY && !foundInAD) estado = 'Habilitado';
      else if (foundInAD && foundInHY) estado = 'En ambos';

      return {
        'Directory Name': name,
        Estado: estado
      };
    });

    const csvWriter = createCsvWriter({
      path: outFile,
      header: [
        { id: 'Directory Name', title: 'Directory Name' },
        { id: 'Estado', title: 'Estado' }
      ],
      fieldDelimiter: ',' // salida con coma
    });

    await csvWriter.writeRecords(resultado);
    console.log(`✅ Archivo generado: ${outFile} (filas: ${resultado.length})`);
  } catch (err) {
    console.error('❌ Error:', err.message);
    process.exit(1);
  }
})();

