// Kl3.js
const fs = require('fs');
const csv = require('csv-parser');
const createCsvWriter = require('csv-writer').createObjectCsvWriter;

const resultadoFile = './resultado_final_kl.csv'; // archivo base (salida de Kl.js)
const av3File = './Archivos/AV3.csv';             // archivo nuevo
const outFile = './resultado_final_kl3.csv';      // salida

// Normalizar textos
function normalize(s) {
  return (s || '').toString().trim().toLowerCase().normalize('NFC');
}

// Leer CSV con separador ,
function readCSV(filePath) {
  return new Promise((resolve, reject) => {
    if (!fs.existsSync(filePath)) {
      return reject(new Error(`No existe el archivo: ${filePath}`));
    }
    const rows = [];
    fs.createReadStream(filePath)
      .pipe(csv({ separator: ',' }))
      .on('data', (row) => rows.push(row))
      .on('end', () => resolve(rows))
      .on('error', reject);
  });
}

(async () => {
  try {
    console.log('📂 Leyendo archivos...');
    const resultadoRows = await readCSV(resultadoFile);
    const av3Rows = await readCSV(av3File);

    console.log(`➡️ Filas en resultado_final_kl.csv: ${resultadoRows.length}`);
    console.log(`➡️ Filas en AV3.csv: ${av3Rows.length}`);

    // Crear set con System Name de AV3
    const av3Set = new Set(av3Rows.map(r => normalize(r['System Name'])));

    let actualizados = 0;

    // Actualizar solo si AV actual es "No"
    const updated = resultadoRows.map(r => {
      const dirName = normalize(r['Directory Name']);
      const currentAV = normalize(r['AV']);
      const currentEPO = r['EPO'];

      if (currentAV === 'no' && av3Set.has(dirName)) {
        actualizados++;
        return {
          ...r,
          AV: 'Sí',
          EPO: 3
        };
      }

      return r;
    });

    const headers = Object.keys(updated[0]).map(k => ({ id: k, title: k }));

    const csvWriter = createCsvWriter({
      path: outFile,
      header: headers,
      fieldDelimiter: ','
    });

    await csvWriter.writeRecords(updated);
    console.log(`✅ Archivo generado: ${outFile} (filas: ${updated.length})`);
    console.log(`🔄 Dispositivos actualizados desde AV3: ${actualizados}`);
  } catch (err) {
    console.error('❌ Error:', err.message);
    process.exit(1);
  }
})();
