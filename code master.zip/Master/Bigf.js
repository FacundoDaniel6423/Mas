// Bigf.js
const fs = require('fs');
const csv = require('csv-parser');
const createCsvWriter = require('csv-writer').createObjectCsvWriter;

const resultadoFile = './resultado_final_kl3.csv'; // archivo base
const bFile = './Archivos/B.csv';                 // archivo B
const outFile = './resultado_final_bigf.csv';     // salida

// Normalizar textos
function normalize(s) {
  return (s || '').toString().trim().toLowerCase().normalize('NFC');
}

// Leer CSV con separador ,
function readCSV(filePath) {
  return new Promise((resolve, reject) => {
    if (!fs.existsSync(filePath)) {
      return reject(new Error(`No existe el archivo: ${filePath}`));
    }
    const rows = [];
    fs.createReadStream(filePath)
      .pipe(csv({ separator: ',' }))
      .on('data', (row) => rows.push(row))
      .on('end', () => resolve(rows))
      .on('error', reject);
  });
}

(async () => {
  try {
    console.log('📂 Leyendo archivos...');
    const resultadoRows = await readCSV(resultadoFile);
    const bRows = await readCSV(bFile);

    console.log(`➡️ Filas en resultado_final_kl3.csv: ${resultadoRows.length}`);
    console.log(`➡️ Filas en B.csv: ${bRows.length}`);

    // Mapear Computer Name → Trellix (respetando mayúscula del archivo real)
    const bMap = new Map(
      bRows.map(r => [normalize(r['Computer Name']), r['Trellix'] || ''])
    );

    let actualizados = 0;

    const updated = resultadoRows.map(r => {
      const dirName = normalize(r['Directory Name']);
      if (bMap.has(dirName)) {
        actualizados++;
        return {
          ...r,
          B: 'Sí',
          Trellix: bMap.get(dirName)
        };
      }
      return {
        ...r,
        B: 'No',
        Trellix: ''
      };
    });

    const headers = Object.keys(updated[0]).map(k => ({ id: k, title: k }));

    const csvWriter = createCsvWriter({
      path: outFile,
      header: headers,
      fieldDelimiter: ','
    });

    await csvWriter.writeRecords(updated);
    console.log(`✅ Archivo generado: ${outFile} (filas: ${updated.length})`);
    console.log(`🔄 Dispositivos encontrados en B.csv: ${actualizados}`);
  } catch (err) {
    console.error('❌ Error:', err.message);
    process.exit(1);
  }
})();
