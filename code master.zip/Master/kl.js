// Kl.js
const fs = require('fs');
const csv = require('csv-parser');
const createCsvWriter = require('csv-writer').createObjectCsvWriter;

const resultadoFile = './resultado_final.csv'; // archivo base
const av2File = './Archivos/AV2.csv';          // archivo nuevo
const outFile = './resultado_final_kl.csv';    // salida

// Normalizar textos
function normalize(s) {
  return (s || '').toString().trim().toLowerCase().normalize('NFC');
}

// Leer CSV con separador ,
function readCSV(filePath) {
  return new Promise((resolve, reject) => {
    if (!fs.existsSync(filePath)) {
      return reject(new Error(`No existe el archivo: ${filePath}`));
    }
    const rows = [];
    fs.createReadStream(filePath)
      .pipe(csv({ separator: ',' }))
      .on('data', (row) => rows.push(row))
      .on('end', () => resolve(rows))
      .on('error', reject);
  });
}

(async () => {
  try {
    console.log('📂 Leyendo archivos...');
    const resultadoRows = await readCSV(resultadoFile);
    const av2Rows = await readCSV(av2File);

    console.log(`➡️ Filas en resultado_final.csv: ${resultadoRows.length}`);
    console.log(`➡️ Filas en AV2.csv: ${av2Rows.length}`);

    // Crear set con System Name de AV2
    const av2Set = new Set(av2Rows.map(r => normalize(r['System Name'])));

    let actualizados = 0;

    // Actualizar solo si AV actual es "No"
    const updated = resultadoRows.map(r => {
      const dirName = normalize(r['Directory Name']);
      const currentAV = normalize(r['AV']);
      const currentEPO = r['EPO'];

      if (currentAV === 'no' && av2Set.has(dirName)) {
        actualizados++;
        return {
          ...r,
          AV: 'Sí',
          EPO: 2
        };
      }

      // Si no corresponde, devolver igual
      return r;
    });

    const headers = Object.keys(updated[0]).map(k => ({ id: k, title: k }));

    const csvWriter = createCsvWriter({
      path: outFile,
      header: headers,
      fieldDelimiter: ','
    });

    await csvWriter.writeRecords(updated);
    console.log(`✅ Archivo generado: ${outFile} (filas: ${updated.length})`);
    console.log(`🔄 Dispositivos actualizados desde AV2: ${actualizados}`);
  } catch (err) {
    console.error('❌ Error:', err.message);
    process.exit(1);
  }
})();
