// StateDevice.js
const fs = require('fs');
const csv = require('csv-parser');
const createCsvWriter = require('csv-writer').createObjectCsvWriter;

const resultadoFile = './resultado.csv';
const avFile = './Archivos/AV.csv';
const outFile = './resultado_final.csv';

// Normalizar textos
function normalize(s) {
  return (s || '').toString().trim().toLowerCase().normalize('NFC');
}

// Leer CSV con separador ,
function readCSV(filePath) {
  return new Promise((resolve, reject) => {
    if (!fs.existsSync(filePath)) {
      return reject(new Error(`No existe el archivo: ${filePath}`));
    }
    const rows = [];
    fs.createReadStream(filePath)
      .pipe(csv({ separator: ',', mapHeaders: ({ index }) => `col${index}` }))
      .on('data', (row) => rows.push(row))
      .on('end', () => resolve(rows))
      .on('error', reject);
  });
}

(async () => {
  try {
    console.log('📂 Leyendo archivos...');
    const resultadoRows = await readCSV(resultadoFile);
    const avRows = await readCSV(avFile);

    console.log(`➡️ Filas en resultado.csv: ${resultadoRows.length}`);
    console.log(`➡️ Filas en AV.csv: ${avRows.length}`);

    // Crear set con nombres de AV (col0 = System Name)
    const avSet = new Set(avRows.map(r => normalize(r['col0'])));

    // Agregar columnas AV y EPO a resultado
    const updated = resultadoRows.map(r => {
      const dirName = normalize(r['col0']); // Directory Name está en col0
      const exists = avSet.has(dirName);
      return {
        ...r,
        AV: exists ? 'Sí' : 'No',
        EPO: exists ? 1 : 0
      };
    });

    const headers = Object.keys(updated[0]).map(k => ({ id: k, title: k }));

    const csvWriter = createCsvWriter({
      path: outFile,
      header: headers,
      fieldDelimiter: ',' // salida con coma
    });

    await csvWriter.writeRecords(updated);
    console.log(`✅ Archivo generado: ${outFile} (filas: ${updated.length})`);
  } catch (err) {
    console.error('❌ Error:', err.message);
    process.exit(1);
  }
})();
